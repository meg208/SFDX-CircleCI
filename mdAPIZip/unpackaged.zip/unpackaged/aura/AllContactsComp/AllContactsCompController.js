({
    doInit : function(component, event, helper){
        helper.getAllContacts(component);
    }
})