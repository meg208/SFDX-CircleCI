({
    myAction : function(component, event, helper) {

    }
})